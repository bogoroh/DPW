# Mike Taatgen
# DPW
# 01-20-14
# Quiz 2

class Land(object):
	def __init__(self):
		def populationCheck(self):
			people = 7023442934239123 # Amount of people on land
			rateIncrease = 4.5 # Rate increase of the amount of people since last year
			return people
			return rateIncrease	
		def populationGrowth(c,p): #Call it out for example: Land.populationGrowth(32432523523,2)
			newPopulation = c * p
			print newPopulation
			return newPopulation
    self._age = 0 # Age of the land
    self._location = "" # Location where the land is

    @property
    def location(self):
        return self._location
    @location.setter
    def location(self, value):
        self._location = value

    @property
    def age(self):
        return self._age
    @age.setter
    def age(self, value):
        self._age = value
    
class Island(Land):
	def __init__(self):
		super(Island, self).__init__()
		self._length = 0

		def sea:
			print("This island is located around the pacific ocean") #this will print out when you call it out like Island.sea()
		def partOf:
			family = "This island is part of the Netherlands" #this will print out when you call it out like Island.partOf()
			print family
			return family

	@property
	def length(self):
	    return self._length
	@length.setter
	def length(self, value):
	    self._length = value
	

